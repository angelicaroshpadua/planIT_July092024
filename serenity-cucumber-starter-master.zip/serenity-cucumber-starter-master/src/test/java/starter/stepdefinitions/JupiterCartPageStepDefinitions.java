package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.en_old.Ac;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Hit;
import net.serenitybdd.screenplay.ensure.Ensure;
import net.serenitybdd.screenplay.questions.Text;
import net.serenitybdd.screenplay.questions.Value;
import net.serenitybdd.screenplay.waits.WaitUntil;
import org.openqa.selenium.Keys;
import starter.targets.JupiterCartPage;
import starter.targets.JupiterShopPage;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.isVisible;

public class JupiterCartPageStepDefinitions {

    private static final DecimalFormat df = new DecimalFormat("0.00");

    @Then("{actor} sees that the Cart page is displayed")
    public void heSeesThatTheCartPageIsDisplayed(Actor actor) {
        actor.attemptsTo(
                WaitUntil.the(JupiterCartPage.CART_ITEMS_TABLE, isVisible()).forNoMoreThan(60).seconds()
        );

        actor.attemptsTo(
                Ensure.that(JupiterCartPage.CART_ITEMS_TABLE).isDisplayed()
        );
    }


    @And("{actor} sees that the unit price of {string} is {string}")
    public void heSeesThatTheUnitPriceOfIs(Actor actor, String itemName, String expectedUnitPrice) {
        actor.attemptsTo(
                Ensure.that(JupiterCartPage.UNIT_PRICE_withItemName.of(itemName)).hasText(expectedUnitPrice)
        );
    }

    @When("{actor} sets the quantity of the {string} to {string}")
    public void heSetsTheQuantityOfTheTo(Actor actor, String itemName, String quantity) {
        actor.attemptsTo(
                Enter.theValue(quantity).into(JupiterCartPage.QUANTITY_FIELD_withItemName.of(itemName)),
                Hit.the(Keys.TAB).into(JupiterCartPage.QUANTITY_FIELD_withItemName.of(itemName))
        );
    }

    @Then("{actor} sees that the correct subtotal for {string} is displayed")
    public void heSeesThatTheCorrectSubtotalForIsDisplayed(Actor actor, String itemName) {
        String displayedUnitPrice = (actor.asksFor(Text.of(JupiterCartPage.UNIT_PRICE_withItemName.of(itemName)))).replace("$", "");
        float unitPrice = Float.parseFloat(displayedUnitPrice);

        String displayedQuantity = actor.asksFor(Value.of(JupiterCartPage.QUANTITY_FIELD_withItemName.of(itemName)));
        float value = Float.parseFloat(displayedQuantity);

        float expectedSubTotal = unitPrice * value;
        expectedSubTotal = Float.parseFloat(df.format(expectedSubTotal));

        String expectedSubTotalDisplayed = "$" + expectedSubTotal;

        String displayedSubTotal = actor.asksFor(Text.of(JupiterCartPage.SUBTOTAL_withItemName.of(itemName)));

        actor.attemptsTo(
                Ensure.that(displayedSubTotal).isEqualTo(expectedSubTotalDisplayed)
        );
    }


    @And("{actor} sees that the correct total price for all purchased items are displayed")
    public void heSeesThatTheCorrectTotalPriceForAllPurchasedItemsAreDisplayed(Actor actor) {
        List<Float> subTotal = new ArrayList<>();
        int numberOfItems = JupiterCartPage.TABLE_ITEMS_ROW_COUNT.resolveAllFor(actor).size();
        System.out.println("The number of items is: " + numberOfItems);

        for (int i = 1; i <= numberOfItems; i++) {
            String rowNumber = String.valueOf(i);
            String displayedSubtotal = (actor.asksFor(Text.of(JupiterCartPage.SUBTOTAL_OF_ITEM_withRowNumber.of(rowNumber))))
                    .replace("$", "");
            float displayedSubTotalFloat = Float.parseFloat(displayedSubtotal);

            subTotal.add(displayedSubTotalFloat);
        }

        System.out.println("The size of array is: " + subTotal.size());
        float sumOfList = 0;
        for (int i = 0; i < subTotal.size(); i++) {
            sumOfList += subTotal.get(i);
        }

        sumOfList = Float.parseFloat(df.format(sumOfList));

        String totalPriceDisplayed = (actor.asksFor(Text.of(JupiterCartPage.TOTAL_PRICE_OF_ITEMS)).replace("Total:", "")).trim();
        String computedTotal = String.valueOf(sumOfList);

        actor.attemptsTo(
                Ensure.that(totalPriceDisplayed).isEqualTo(computedTotal)
        );
    }

}
