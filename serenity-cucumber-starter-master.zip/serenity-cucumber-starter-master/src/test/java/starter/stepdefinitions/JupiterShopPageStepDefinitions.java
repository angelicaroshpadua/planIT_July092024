package starter.stepdefinitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.ensure.Ensure;
import net.serenitybdd.screenplay.waits.WaitUntil;
import starter.targets.*;
import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.*;

public class JupiterShopPageStepDefinitions {

    @Then("{actor} sees that the Shop page is displayed")
    public void heSeesThatTheShopPageIsDisplayed(Actor actor) {
        actor.attemptsTo(
                WaitUntil.the(JupiterShopPage.SHOP_PAGE_BODY, isVisible()).forNoMoreThan(60).seconds()
        );

        actor.attemptsTo(
                Ensure.that(JupiterShopPage.SHOP_PAGE_BODY).isDisplayed()
        );
    }

    @When("{actor} adds the {string} to the cart")
    public void heAddsTheToTheCart(Actor actor, String item) {
        actor.attemptsTo(
                Click.on(JupiterShopPage.BUY_BUTTON_withItemName.of(item))
        );
    }

}
