package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Hit;
import net.serenitybdd.screenplay.ensure.Ensure;
import net.serenitybdd.screenplay.waits.WaitUntil;
import org.openqa.selenium.Keys;
import starter.targets.*;
import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.*;

public class JupiterContactPageStepDefinitions {

    @When("{actor} selects {string} from the upper menu")
    public void heSelectsContactFromTheUpperMenu(Actor actor, String menuName) {
        actor.attemptsTo(
                Click.on(JupiterHomePage.UPPER_MENU_BUTTON_withTabName.of(menuName))
        );
    }


    @Then("{actor} sees that the Contact page is displayed")
    public void heSeesThatTheContactPageIsDisplayed(Actor actor) {
        actor.attemptsTo(
                WaitUntil.the(JupiterContactPage.FEEDBACK_BANNER, isVisible()).forNoMoreThan(30).seconds()
        );

        actor.attemptsTo(
                Ensure.that(JupiterContactPage.FEEDBACK_BANNER).isDisplayed()
        );
    }


    @When("{actor} clicks the submit button")
    public void heClicksTheSubmitButton(Actor actor) {
        actor.attemptsTo(
                Click.on(JupiterContactPage.SUBMIT_BUTTON)
        );
    }

    @Then("{actor} sees that the error message banner is {string}")
    public void heSeesThatTheErrorMessageBannerIs(Actor actor, String errorMessageVisibility) {
        if (errorMessageVisibility.equalsIgnoreCase("displayed")) {
            actor.attemptsTo(
                    Ensure.that(JupiterContactPage.ERROR_MESSAGE_BANNER).isDisplayed()
            );
        } else if (errorMessageVisibility.equalsIgnoreCase("not displayed")) {
            actor.attemptsTo(
                    Ensure.that(JupiterContactPage.ERROR_MESSAGE_BANNER).isNotDisplayed()
            );
        }
    }

    @And("{actor} sees that the error messages for the required fields are {string}")
    public void heSeesThatTheErrorMessagesForTheRequiredFieldsAre(Actor actor, String errorMessageVisibility) {
        if (errorMessageVisibility.equalsIgnoreCase("displayed")) {
            actor.attemptsTo(
                    Ensure.that(JupiterContactPage.REQUIRED_FIELDS_ERROR_MESSAGE_withFieldName.of("Forename")).isDisplayed(),
                    Ensure.that(JupiterContactPage.REQUIRED_FIELDS_ERROR_MESSAGE_withFieldName.of("Email")).isDisplayed(),
                    Ensure.that(JupiterContactPage.REQUIRED_FIELDS_ERROR_MESSAGE_withFieldName.of("Message")).isDisplayed()
            );
        } else if (errorMessageVisibility.equalsIgnoreCase("not displayed")) {
            actor.attemptsTo(
                    Ensure.that(JupiterContactPage.REQUIRED_FIELDS_ERROR_MESSAGE_withFieldName.of("Forename")).isNotDisplayed(),
                    Ensure.that(JupiterContactPage.REQUIRED_FIELDS_ERROR_MESSAGE_withFieldName.of("Email")).isNotDisplayed(),
                    Ensure.that(JupiterContactPage.REQUIRED_FIELDS_ERROR_MESSAGE_withFieldName.of("Message")).isNotDisplayed()
            );
        }
    }

    @When("{actor} enters {string} in the {string} field")
    public void heEntersInTheField(Actor actor, String value, String fieldName) {
        fieldName = fieldName.toLowerCase();

        actor.attemptsTo(
                Enter.theValue(value).into(JupiterContactPage.INPUT_FIELD_withFieldName.of(fieldName)),
                Hit.the(Keys.TAB).into(JupiterContactPage.INPUT_FIELD_withFieldName.of(fieldName))
        );
    }

    @And("{actor} enters {string} in the message text area field")
    public void heEntersInTheMessageTextAreaField(Actor actor, String value) {
        actor.attemptsTo(
                Enter.theValue(value).into(JupiterContactPage.MESSAGE_TEXT_AREA_FIELD),
                Hit.the(Keys.TAB).into(JupiterContactPage.MESSAGE_TEXT_AREA_FIELD)
        );
    }

    @Then("{actor} sees that the feedback has been submitted")
    public void heSeesThatTheFeedbackHasBeenSubmitted(Actor actor) {
        actor.attemptsTo(
                WaitUntil.the(JupiterContactPage.SENDING_FEEDBACK_POPUP_LOADING_MESSAGE, isNotVisible()).forNoMoreThan(60).seconds()
        );

        actor.attemptsTo(
                Ensure.that(JupiterContactPage.SUCCESSFUL_FEEDBACK_SUBMITTED_MESSAGE).isDisplayed()
        );
    }

}
