package starter.targets;

import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.pages.PageObject;

public class JupiterShopPage extends PageObject {

    public static final Target SHOP_PAGE_BODY = Target
            .the(" Shop page page body")
            .locatedBy("//div[contains(@class,'products')]");

    public static final Target BUY_BUTTON_withItemName = Target
            .the(" BUY button for Item {0}")
            .locatedBy("//h4[text()='{0}']/..//p//a[text()='Buy']");
}