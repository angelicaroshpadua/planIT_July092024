package starter.targets;

import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.pages.PageObject;

public class JupiterHomePage extends PageObject {

    public static final Target UPPER_MENU_BUTTON_withTabName = Target
            .the(" {0} tab of the Upper Menu")
            .locatedBy("//li//a[contains(text(), '{0}')]");

}