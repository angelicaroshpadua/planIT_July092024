package starter.targets;

import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.pages.PageObject;

public class JupiterContactPage extends PageObject {

    public static final Target FEEDBACK_BANNER = Target
            .the(" Feedback Banner in the Contact Page")
            .locatedBy("//div[contains(@class, 'alert-info')]//strong[contains(text(),'We welcome your feedback')]");

    public static final Target SUBMIT_BUTTON = Target
            .the(" Submit Button")
            .locatedBy("//a[text()='Submit']");

    public static final Target ERROR_MESSAGE_BANNER = Target
            .the(" Error Message Banner in the Contact Page")
            .locatedBy("//div[contains(@class, 'alert-error')]//strong[contains(text(),'We welcome your feedback')]");

    public static final Target REQUIRED_FIELDS_ERROR_MESSAGE_withFieldName = Target
            .the(" Error Message for the Required Field {0}")
            .locatedBy("//span[contains(@id, 'err') and contains(text(), '{0} is required')]");

    public static final Target INPUT_FIELD_withFieldName = Target
            .the(" text input Field for field name {0}")
            .locatedBy("//input[@id='{0}']");

    public static final Target MESSAGE_TEXT_AREA_FIELD = Target
            .the(" Message text area field")
            .locatedBy("//textarea[@id='message']");

    public static final Target SENDING_FEEDBACK_POPUP_LOADING_MESSAGE = Target
            .the(" Sending Feedback Loading message")
            .locatedBy("//div[@class='modal-header']//h1[text()='Sending Feedback']");

    public static final Target SUCCESSFUL_FEEDBACK_SUBMITTED_MESSAGE = Target
            .the(" Successful feedback submitted message")
            .locatedBy("//div[contains(@class,'alert-success')]");


}